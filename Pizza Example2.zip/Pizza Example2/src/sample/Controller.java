package sample;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.util.ArrayList;

public class Controller {
public Button doIt;
public Button LoginButton;
public Button RegisterButton;
public Label WelcomeLabel;
public TextField UserText;
public TextField PassText;
public Button GoToPage;
public Label Notify;
public TextField FName;
public TextField LName;
public TextField PhoneNum;
public TextField Email;
public TextField UName;
public TextField pWord;
public Label NoReg;
public Button goBack;


ArrayList<String> UserNames = new ArrayList<>(0);
ArrayList<String> PassWords = new ArrayList<>(0);

public void Welcome(ActionEvent actionEvent) throws Exception{
    Parent root1 = FXMLLoader.load(getClass().getResource("sample.fxml"));
    Stage stage1= new Stage();
    stage1.setTitle("LoginScreen");
    stage1.setScene(new Scene(root1, 500,500));
    stage1.show();


}




public void Log(ActionEvent actionEvent) throws Exception{
    Parent root2 = FXMLLoader.load(getClass().getResource("Login.fxml"));
    Stage stage2= new Stage();
    stage2.setTitle("Enter the following to proceed");
    stage2.setScene(new Scene(root2, 500,500));
    stage2.show();

}


public void Create(ActionEvent actionEvent) throws Exception{

    Parent root3 = FXMLLoader.load(getClass().getResource("Register.fxml"));
    Stage stage3= new Stage();
    stage3.setTitle("Create an Account");
    stage3.setScene(new Scene(root3, 500,500));
    stage3.show();

}
public void CheckLogin(ActionEvent actionEvent) {
    String UT= UserText.getText();
    String PT = PassText.getText();
    if(UT.isBlank() || PT.isBlank()){
     Notify.setText("No UserName or Password");
    }
  /*  if(UserNames.contains(UT) && PassWords.contains(PT)){
        Notify.setText("Valid Login");
    }
    else{
        Notify.setText("Invalid Login");
    }
*/
for (int i=0; i< UserNames.size(); i++){

    if(UserNames.get(i).equals(UT) && PassWords.get(i).equals(PT) ){
        Notify.setText("Valid Login");

    }

    else{
      //  Notify.setText("Invalid Login");
    }
}



}

public void CheckReg(ActionEvent actionEvent){
    String Un= UName.getText();
    String pW= pWord.getText();

    if(FName.getText().isBlank() || LName.getText().isBlank() || PhoneNum.getText().isBlank() || Email.getText().isBlank() || UName.getText().isBlank() || pWord.getText().isBlank()){
        NoReg.setText("One or more of the following fields is empty");

    }

    else{
        UserNames.add(Un);
        PassWords.add(pW);
        NoReg.setText("Registration Complete");

    }


}


}
